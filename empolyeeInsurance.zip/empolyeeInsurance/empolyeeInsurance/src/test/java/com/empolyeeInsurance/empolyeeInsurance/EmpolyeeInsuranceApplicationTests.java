package com.empolyeeInsurance.empolyeeInsurance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpolyeeInsuranceApplicationTests {

	@Test
	void contextLoads() {
	}

}
