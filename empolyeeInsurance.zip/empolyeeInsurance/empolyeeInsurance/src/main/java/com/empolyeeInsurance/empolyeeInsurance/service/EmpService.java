package com.empolyeeInsurance.empolyeeInsurance.service;

public class EmpService {

}
