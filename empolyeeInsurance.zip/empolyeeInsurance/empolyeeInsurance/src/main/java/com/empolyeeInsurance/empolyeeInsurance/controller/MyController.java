package com.empolyeeInsurance.empolyeeInsurance.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.empolyeeInsurance.empolyeeInsurance.entities.Employee;

@RestController
public class MyController {

	
	private Employee emp = new Employee();

	@GetMapping("/home")
	public Employee home() {

		// emp.setId(1);
		// emp.setfName("ram");
		// emp.setlName("kaka");

		return emp;
	}

	@PostMapping("/home")
	public Employee add(@RequestBody Employee emp) {

		System.out
				.println("empId=" + emp.getId() + "emp first name" + emp.getfName() + "emp last name" + emp.getlName());

		return emp;

	}

}
